import java.util.Arrays;

public class puzzleJavaTesting {
  public static void main(String[] args){
    puzzleJava myPuzzle = new puzzleJava();

    // String result = myPuzzle.greaterThan10();
    // System.out.println(result);
    // String result = myPuzzle.names();
    // System.out.println(result);
    // myPuzzle.alphabet();
    // String str = Arrays.toString(myPuzzle.randomInt());
    // System.out.println(str);
    // String str = Arrays.toString(myPuzzle.randomIntSort());
    // System.out.println(str);
    // String str = myPuzzle.randString();
    // System.out.println(str);

    //String str = myPuzzle.randString10();
    //System.out.println(str);
  }
}