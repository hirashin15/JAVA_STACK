public class firstJavaProgram {
  public static void main(String[] args) {
    System.out.println("My name is Hira Shin");
    System.out.println("I am 25 years old.");
    System.out.println("I am from Seattle, WA");

  }
}