public class pythagoreanTest {
  public static void main(String[]  args) {
    pythagorean py = new pythagorean();
    double hypotenuse = py.calculateHypotenuse(3, 4);
    System.out.println(hypotenuse);
  }
}