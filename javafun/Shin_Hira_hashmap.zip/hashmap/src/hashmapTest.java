
public class hashmapTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		hashmap map = new hashmap();
		map.songsList();

	}

}
