public class fizzBuzzTest {
  public static void main(String[] args) {
    fizzBuzz fb = new fizzBuzz();
    System.out.println(fb.fizzBuzz(3));
    System.out.println(fb.fizzBuzz(5));
    System.out.println(fb.fizzBuzz(15));
    System.out.println(fb.fizzBuzz(2));
  }
}